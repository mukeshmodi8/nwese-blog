const videos = [
  {
    id: 1,
    title: "AI Future Phone",
    url: "https://www.youtube.com/embed/Ct9-pI_atuk",
  },
  {
    id: 5,
    title: "Build Your First AI Agent in 15 Minutes (NO CODING)",
    url: "https://www.youtube.com/embed/lIDIEKkRrGI",
  },
  {
    id: 6,
    title: "Complete AI Roadmap for Beginners – From Basics to Building Real AI Projects",
    url: "https://www.youtube.com/embed/ACcvVvljKYQ",
  },
  {
    id: 7,
    title: "Google Web Stories Tutorial by @SatishKVideos | FREE Course",
    url: "https://www.youtube.com/embed/yTSYA4gFfxQ",
  },
  {
    id: 8,
    title: "What is Artificial Intelligence With Full Information? – [Hindi] – Quick Support",
    url: "https://www.youtube.com/embed/iyb38dzetRk",
  },
  {
    id: 2,
    title: "लेटेस्ट न्यूज़ 🔴 LIVE",
    url: "https://www.youtube.com/embed/09aBnCM3jKo",
  },
  {
    id: 3,
    title: "इतिहास की सच्चाई | Documentary",
    url: "https://www.youtube.com/embed/ebuuykyk-eE",
  },
  {
    id: 4,
    title: "OnePlus 12 का धमाकेदार रिव्यू!",
    url: "https://www.youtube.com/embed/pijEZbZemUM",
  },
  
];

export default videos;
