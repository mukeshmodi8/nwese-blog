const sportsData = {
  blogs: [
    {
      id: 1,
      title: "India Wins the Toss and Elects to Bat",
      image: "/images/cricket1.jpg",
      content: "India started strong after winning the toss...",
      publishedAt: "2025-07-06",
    },
    {
      id: 2,
      title: "Rohit Sharma hits a blazing 60",
      image: "/images/cricket2.jpg",
      content: "Captain Rohit leads from the front...",
      publishedAt: "2025-07-06",
    }
  ],
};

export default sportsData;
