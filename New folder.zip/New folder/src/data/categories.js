export const categories = ["Technology", "Health", "Sports", "Entertainment", "Business","news", "Travel",
     "Education", "Science", "Politics", "Finance", "Food", "Fashion", "Gaming", "Environment", "Automotive",
      "Real Estate", "Art & Culture"];
