// import React from "react";
// import { Link } from "react-router-dom";
// import "./AppDownloadBanner.css"; 

// const AppDownloadBanner = () => {
//   return (
//     <div className="app-download-banner">
//       <p className="app-download-text">
//         📱 Download our app for the best experience!{" "}
//         <Link to="/download" className="app-download-link">
//           Click Here
//         </Link>
//       </p>
//     </div>
//   );
// };

// export default AppDownloadBanner;
