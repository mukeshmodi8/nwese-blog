// import AdminLogin from "./admin/src/pages/AdminLogin";
// import AdminRegister from "./admin/src/pages/AdminRegister";
// import AddProduct from "./admin/src/pages/AddProduct";
// import ManageProducts from "./admin/src/pages/ManageProducts";
// import ProtectedRoute from "./admin/ProtectedRoute";
// import AdminPanel from "./admin/src/pages/AdminPanel"; // ✅ यही गलती थी



// function App() {
//   return (
//     <Routes>
//       <Route path="/admin/register" element={<AdminRegister />} />
//       <Route path="/admin/login" element={<AdminLogin />} />
//       <Route
//         path="/admin/dashboard"
//         element={
//           <ProtectedRoute>
//             <AdminPanel />
//           </ProtectedRoute>
//         }
//       />
//       <Route
//         path="/admin/add"
//         element={
//           <ProtectedRoute>
//             <AddProduct />
//           </ProtectedRoute>
//         }
//       />
//       <Route
//         path="/admin/products"
//         element={
//           <ProtectedRoute>
//             <ManageProducts />
//           </ProtectedRoute>
//         }
//       />
//     </Routes>
//   );
// }

// export default App;
